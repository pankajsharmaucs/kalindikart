// app/login/page.jsx
'use client';

import React, { useState, useCallback } from 'react';
import Link from 'next/link';

export default function LoginPage() {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);

    const handleLogin = useCallback(async (e) => {
        e.preventDefault();
        setLoading(true);
        setError(null);

        if (!email || !password) {
            setError('Please enter both email and password.');
            setLoading(false);
            return;
        }

        try {
            await new Promise(resolve => setTimeout(resolve, 1500));
            if (email === 'user@example.com' && password === 'password') {
                alert('Login successful! Redirecting...');
            } else {
                setError('Invalid credentials. (Mock user: user@example.com, password: password)');
            }
        } catch (err) {
            setError('Network error occurred during login.');
        } finally {
            setLoading(false);
        }
    }, [email, password]);

    return (
        <div className="login-page">
            <div className="login-wrapper">
                <header className="text-center mb-4">
                    <i className="bi bi-box-arrow-in-right display-3 text-primary-gold mb-3"></i>
                    <h1 className="h3 fw-bold text-dark-gold mb-1">Welcome Back</h1>
                    <p className="text-muted small">Sign in to your account to continue</p>
                </header>

                <div className="login-card shadow-lg p-4 p-md-5 rounded-4">
                    {error && (
                        <div className="alert alert-danger small mb-3" role="alert">
                            <i className="bi bi-exclamation-triangle-fill me-2"></i>{error}
                        </div>
                    )}

                    <form onSubmit={handleLogin}>
                        <div className="mb-4">
                            <label htmlFor="emailInput" className="form-label fw-semibold text-dark-gold">Email Address</label>
                            <div className="input-group input-group-lg">
                                <span className="input-group-text">
                                    <i className="bi bi-envelope-fill"></i>
                                </span>
                                <input
                                    type="email"
                                    id="emailInput"
                                    placeholder="name@example.com"
                                    className="form-control"
                                    value={email}
                                    onChange={(e) => setEmail(e.target.value)}
                                    required
                                />
                            </div>
                        </div>

                        <div className="mb-4">
                            <label htmlFor="passwordInput" className="form-label fw-semibold text-dark-gold">Password</label>
                            <div className="input-group input-group-lg">
                                <span className="input-group-text">
                                    <i className="bi bi-lock-fill"></i>
                                </span>
                                <input
                                    type="password"
                                    id="passwordInput"
                                    placeholder="Enter your password"
                                    className="form-control"
                                    value={password}
                                    onChange={(e) => setPassword(e.target.value)}
                                    required
                                />
                            </div>
                        </div>

                        <div className="d-grid mb-4">
                            <button type="submit" className="btn btn-primary-gold text-white btn-xl" disabled={loading}>
                                {loading ? (
                                    <>
                                        <span className="spinner-border spinner-border-sm me-2" role="status"></span>
                                        Authenticating...
                                    </>
                                ) : (
                                    <>
                                        <i className="bi bi-check-circle-fill me-2"></i>
                                        Login Securely
                                    </>
                                )}
                            </button>
                        </div>

                        <div className="text-center small">
                            <p className="mb-1">
                                Don't have an account?{' '}
                                <Link href="/signup" className="text-primary-gold fw-bold text-decoration-none hover-dark-gold">
                                    Register Here
                                </Link>
                            </p>
                            <p>
                                <Link href="/" className="text-muted text-decoration-none hover-dark-gold">
                                    Forgot Password?
                                </Link>
                            </p>
                        </div>
                    </form>
                </div>
            </div>

            <style jsx global>{`
              
                .login-page {
                    min-height: 100vh;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    padding: 2rem;
                }

                .login-wrapper {
                    width: 100%;
                    max-width: 420px;
                    text-align: center;
                }

                .login-card {
                    background: var(--white-alpha);
                    backdrop-filter: blur(10px);
                    border-radius: 2rem;
                    box-shadow: 0 20px 40px rgba(0, 0, 0, 0.15);
                    transition: transform 0.3s ease, box-shadow 0.3s ease;
                }
                .login-card:hover {
                    transform: translateY(-5px);
                    box-shadow: 0 25px 50px rgba(0, 0, 0, 0.25);
                }

                .text-primary-gold { color: var(--primary-gold) !important; }
                .text-dark-gold { color: var(--dark-gold) !important; }
                .hover-dark-gold:hover { color: var(--dark-gold) !important; }

                .btn-primary-gold {
                    background-color: var(--primary-gold);
                    border-color: var(--primary-gold);
                    font-weight: 700;
                    padding: 0.75rem 1.5rem;
                    transition: all 0.3s ease;
                }
                .btn-primary-gold:hover {
                    background-color: var(--dark-gold);
                    border-color: var(--dark-gold);
                    transform: translateY(-2px);
                    box-shadow: 0 6px 12px rgba(0, 115, 157, 0.3);
                }
                .btn-xl { font-size: 1.2rem; }

                .input-group-text {
                    background-color: var(--light-bg);
                    border-right: none;
                    color: var(--dark-gold);
                    font-size: 1.2rem;
                }
                .form-control {
                    border-left: none;
                    padding-left: 0.5rem;
                    height: calc(2.5rem + 0.5rem);
                }
                .form-control:focus {
                    box-shadow: 0 0 0 0.25rem rgba(1, 169, 230, 0.25);
                    border-color: var(--primary-gold);
                }
            `}</style>
        </div>
    );
}
